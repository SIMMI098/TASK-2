import tkinter as tk
from tkinter import messagebox
import math

# Initialize the board
def reset_board():
    global board
    board = [[' ' for _ in range(3)] for _ in range(3)]
    for i in range(3):
        for j in range(3):
            buttons[i][j].config(text=' ', state='normal')

# Check for winner or tie
def check_winner(b):
    for i in range(3):
        if b[i][0] == b[i][1] == b[i][2] != ' ':
            return b[i][0]
        if b[0][i] == b[1][i] == b[2][i] != ' ':
            return b[0][i]
    if b[0][0] == b[1][1] == b[2][2] != ' ':
        return b[0][0]
    if b[0][2] == b[1][1] == b[2][0] != ' ':
        return b[0][2]
    if all(cell != ' ' for row in b for cell in row):
        return 'Tie'
    return None

# Minimax algorithm with alpha-beta pruning
def minimax(b, depth, is_max, alpha, beta):
    result = check_winner(b)
    if result:
        return {'O': 1, 'X': -1, 'Tie': 0}[result]

    if is_max:
        max_eval = -math.inf
        for i in range(3):
            for j in range(3):
                if b[i][j] == ' ':
                    b[i][j] = 'O'
                    score = minimax(b, depth + 1, False, alpha, beta)
                    b[i][j] = ' '
                    max_eval = max(max_eval, score)
                    alpha = max(alpha, score)
                    if beta <= alpha:
                        break
        return max_eval
    else:
        min_eval = math.inf
        for i in range(3):
            for j in range(3):
                if b[i][j] == ' ':
                    b[i][j] = 'X'
                    score = minimax(b, depth + 1, True, alpha, beta)
                    b[i][j] = ' '
                    min_eval = min(min_eval, score)
                    beta = min(beta, score)
                    if beta <= alpha:
                        break
        return min_eval

# Get best move for AI
def best_move():
    best_score = -math.inf
    move = None
    for i in range(3):
        for j in range(3):
            if board[i][j] == ' ':
                board[i][j] = 'O'
                score = minimax(board, 0, False, -math.inf, math.inf)
                board[i][j] = ' '
                if score > best_score:
                    best_score = score
                    move = (i, j)
    return move

# Button click event
def on_click(row, col):
    if board[row][col] == ' ':
        board[row][col] = 'X'
        buttons[row][col].config(text='X', state='disabled')
        result = check_winner(board)
        if result:
            end_game(result)
            return

        ai_row, ai_col = best_move()
        board[ai_row][ai_col] = 'O'
        buttons[ai_row][ai_col].config(text='O', state='disabled')
        result = check_winner(board)
        if result:
            end_game(result)

# Game end logic
def end_game(winner):
    if winner == 'Tie':
        messagebox.showinfo("Game Over", "It's a Tie!")
    elif winner == 'X':
        messagebox.showinfo("Game Over", "You Win!")
    else:
        messagebox.showinfo("Game Over", "AI Wins!")
    # Enable Restart Button
    restart_btn.config(state='normal')

# --- GUI SETUP ---
root = tk.Tk()
root.title("Tic Tac Toe - AI (Unbeatable)")

board = [[' ' for _ in range(3)] for _ in range(3)]
buttons = [[None for _ in range(3)] for _ in range(3)]

# Create game grid
for i in range(3):
    for j in range(3):
        buttons[i][j] = tk.Button(root, text=' ', font=('Arial', 40), width=5, height=2,
                                  command=lambda i=i, j=j: on_click(i, j))
        buttons[i][j].grid(row=i, column=j)

# Restart Button
restart_btn = tk.Button(root, text="Restart", font=('Arial', 14), state='disabled', command=lambda: [reset_board(), restart_btn.config(state='disabled')])
restart_btn.grid(row=3, column=0, columnspan=3, sticky="nsew", pady=10)

root.mainloop()
